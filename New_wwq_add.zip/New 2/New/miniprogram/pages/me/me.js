var app=getApp()
Page({
  data:{
    orderItems:[
    {
      typeId:0,
      name:'接单记录'
    }
  ]
  },
 toSend:function(){
   wx.navigateTo({
     url: 'pages/mytask/mytask'
   })
 },
 jump(){                        //返回注册页面
  wx.navigateTo({
    url: '/pages/mytask/mytask'
  })
},
})