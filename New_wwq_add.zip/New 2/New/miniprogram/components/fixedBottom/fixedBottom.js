// components/fixedBottom/fixedBottom.js
Component({
  options:{
    multipleSlots: true
  },
  properties: {
    defaultButton: {
      type: String,//类型
      value: '提交'//默认值
    },
  },
  data: {
    
  }
})
